package lib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    public static void main(String[] args) {
        String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=FEMINICIDIO;user=sa;password=TecInfo";

        try {
            // Registra o driver do SQL Server
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            
            // Estabelece a conexão
            Connection conexao = DriverManager.getConnection(connectionUrl);

            // Use a conexão aqui (coloque o código que precisa executar com o banco de dados)

            // Fecha a conexão
            conexao.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
