/**
 * 
 */
/**
 * 
 */
module Connectorsql {
	requires java.sql;
}